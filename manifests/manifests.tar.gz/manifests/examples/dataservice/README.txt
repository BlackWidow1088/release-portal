Steps to start dataservice-operator

1. Login to the secondary/slave cluster
dctl -s <VIP> login

2. Extract the helm chart
cp /usr/share/diamanti/ui/helm/charts/dataservice-operator-0.1.2.tgz ~
tar -zxf dataservice-operator-0.1.2.tgz
cd dataservice-operator

3. Install the helm chart
helm install . -n slave

4. Create PVC group CR. This should be identical to the one which will be created on master cluster
kubectl create -f /usr/share/diamanti/manifests/examples/dataservice/crs/dataservice_v1alpha1_pvcgroup_cr.yaml

5. Modify the value of .spec.type in the sample spec to "slave" and create it:
kubectl create -f /usr/share/diamanti/manifests/examples/dataservice/crs/dataservice_v1alpha1_replication_slave_cr.yaml

6. Ensure the slave deployment has started a successful server pod
kubectl get pod --all-namespaces 

7. Login to the primary/master cluster
dctl -s <VIP> login

8. Install the helm chart
helm install . -n slave

9. Modify the PVC Group CR spec so it is identical to the slave cluster and create the PVC group
kubectl create -f /usr/share/diamanti/manifests/examples/dataservice/crs/dataservice_v1alpha1_pvcgroup_cr.yaml

10. Modify the value of .spec.type in the sample spec to "master" and create it:
kubectl create -f /usr/share/diamanti/manifests/examples/dataservice/crs/dataservice_v1alpha1_replication_master_cr.yaml

11. Ensure a cronjob has started running successfully
kubectl get cronjob --all-namespaces

